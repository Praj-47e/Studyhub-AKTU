const searchInput = document.getElementById('searchInput');
const semesterFilter = document.getElementById('semesterFilter');
const typeFilter = document.getElementById('typeFilter');
const cards = [...document.querySelectorAll('.material-card')];
const resultCount = document.getElementById('resultCount');
const emptyState = document.getElementById('emptyState');
const grid = document.getElementById('materialGrid');

function filterMaterials() {
  const query = searchInput.value.trim().toLowerCase();
  const semester = semesterFilter.value;
  const type = typeFilter.value;
  let visible = 0;

  cards.forEach(card => {
    const matchesQuery = !query || card.dataset.search.toLowerCase().includes(query) ||
      card.querySelector('h3').textContent.toLowerCase().includes(query);
    const matchesSemester = semester === 'all' || card.dataset.semester === semester;
    const matchesType = type === 'all' || card.dataset.type === type;
    const show = matchesQuery && matchesSemester && matchesType;
    card.hidden = !show;
    if (show) visible++;
  });

  resultCount.textContent = `Showing ${visible} sample ${visible === 1 ? 'item' : 'items'}`;
  emptyState.hidden = visible !== 0;
  grid.hidden = visible === 0;
}

searchInput.addEventListener('input', filterMaterials);
semesterFilter.addEventListener('change', filterMaterials);
typeFilter.addEventListener('change', filterMaterials);

document.getElementById('resetFilters').addEventListener('click', () => {
  searchInput.value = '';
  semesterFilter.value = 'all';
  typeFilter.value = 'all';
  filterMaterials();
});

document.querySelectorAll('[data-filter]').forEach(link => {
  link.addEventListener('click', () => {
    typeFilter.value = link.dataset.filter;
    filterMaterials();
  });
});

document.querySelectorAll('[data-subject]').forEach(button => {
  button.addEventListener('click', () => {
    const subject = button.dataset.subject.toLowerCase();
    searchInput.value = subject;
    semesterFilter.value = 'all';
    typeFilter.value = 'all';
    filterMaterials();
    document.getElementById('materials').scrollIntoView({ behavior: 'smooth' });
  });
});

document.querySelectorAll('.placeholder-link').forEach(link => {
  link.addEventListener('click', event => {
    event.preventDefault();
    alert('Add your PDF link here first. See the README for simple instructions.');
  });
});

const sidebar = document.getElementById('sidebar');
const menuToggle = document.getElementById('menuToggle');
menuToggle.addEventListener('click', () => {
  const open = sidebar.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.textContent = open ? '×' : '☰';
});
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.nav-link').forEach(item => item.classList.remove('active'));
    link.classList.add('active');
    sidebar.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.textContent = '☰';
  });
});

filterMaterials();
