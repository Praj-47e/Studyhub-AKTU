const catalog = window.STUDYHUB_SUBJECTS || {};
const semesterNames = ["First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth"];
const descriptions = [
  "Build your foundation with core engineering subjects.",
  "Strengthen fundamentals and develop programming skills.",
  "Move into core computer science and problem-solving.",
  "Build core knowledge across systems, algorithms and data.",
  "Explore advanced computing and practical web technologies.",
  "Deepen your CSE skills with specialized core subjects.",
  "Explore advanced electives, projects and industry learning.",
  "Bring your learning together through projects and electives."
];
const types = ["Notes","PYQs","Important Questions"];
const typeShort = {"Notes":"NOTES","PYQs":"PYQ PAPERS","Important Questions":"IMPORTANT Qs"};
const semesterTabs = document.getElementById("semesterTabs");
const subjectList = document.getElementById("subjectList");
const panelTitle = document.getElementById("panelTitle");
const panelSub = document.getElementById("panelSub");
const panelKicker = document.getElementById("panelKicker");
const subjectCount = document.getElementById("subjectCount");
const search = document.getElementById("search");
const libSemester = document.getElementById("libSemester");
const libType = document.getElementById("libType");
const resourceGrid = document.getElementById("resourceGrid");
const libraryCount = document.getElementById("libraryCount");
const noResults = document.getElementById("noResults");
let activeSemester = "1";

document.getElementById("subjectTotal").textContent =
  Object.values(catalog).reduce((sum, list) => sum + list.length, 0);

for (let n = 1; n <= 8; n++) {
  const tab = document.createElement("button");
  tab.className = "semester-tab" + (String(n) === activeSemester ? " active" : "");
  tab.setAttribute("role", "tab");
  tab.setAttribute("aria-selected", String(String(n) === activeSemester));
  tab.innerHTML = `<b>0${n}</b><small>${semesterNames[n-1]}</small>`;
  tab.addEventListener("click", () => selectSemester(String(n)));
  semesterTabs.appendChild(tab);

  const option = document.createElement("option");
  option.value = String(n);
  option.textContent = `${n}${n===1?"st":n===2?"nd":n===3?"rd":"th"} Semester`;
  libSemester.appendChild(option);
}

function selectSemester(n) {
  activeSemester = n;
  [...semesterTabs.children].forEach((tab, i) => {
    const active = String(i + 1) === n;
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", String(active));
  });
  panelKicker.textContent = `SEMESTER 0${n}`;
  panelTitle.textContent = `${semesterNames[Number(n)-1]} semester`;
  panelSub.textContent = descriptions[Number(n)-1];
  const list = catalog[n] || [];
  subjectCount.textContent = `${list.length} subjects`;
  subjectList.innerHTML = "";
  list.forEach((subject, index) => {
    const [name, code, category] = subject;
    const row = document.createElement("div");
    row.className = "subject-row";
    row.innerHTML = `<span class="subject-num">${String(index+1).padStart(2,"0")}</span>
      <span class="subject-info"><b>${name}</b><small>${code} · ${category}</small></span>
      <button type="button">Resources ↗</button>`;
    row.querySelector("button").addEventListener("click", () => {
      search.value = name;
      libSemester.value = n;
      libType.value = "all";
      renderResources();
      document.getElementById("library").scrollIntoView({behavior:"smooth"});
    });
    subjectList.appendChild(row);
  });
}

function allSubjects() {
  return Object.entries(catalog).flatMap(([semester, list]) =>
    list.map(([name, code, category]) => ({semester, name, code, category})));
}

function renderResources() {
  const query = search.value.trim().toLowerCase();
  const sem = libSemester.value;
  const type = libType.value;
  const results = allSubjects().filter(item =>
    (sem === "all" || item.semester === sem) &&
    (!query || `${item.name} ${item.code} ${item.category} semester ${item.semester}`.toLowerCase().includes(query))
  );
  const totalCards = results.length * (type === "all" ? 3 : 1);
  libraryCount.textContent = `Showing ${totalCards} resource ${totalCards === 1 ? "listing" : "listings"}`;
  resourceGrid.innerHTML = "";
  results.forEach(item => {
    (type === "all" ? types : [type]).forEach(kind => {
      const card = document.createElement("article");
      card.className = "resource-card";
      const badgeClass = kind === "PYQs" ? "pyq" : kind === "Important Questions" ? "important" : "";
      const icon = kind === "PYQs" ? "▧" : kind === "Important Questions" ? "✎" : "▤";
      card.innerHTML = `<div class="resource-top"><span class="resource-icon">${icon}</span><span class="resource-type ${badgeClass}">${typeShort[kind]}</span></div>
        <h4>${item.name}</h4><p>${item.semester}${item.semester==="1"?"st":item.semester==="2"?"nd":item.semester==="3"?"rd":"th"} semester · ${item.code}</p>
        <div class="resource-bottom"><small>PDF link not added</small><button type="button">Add material ↗</button></div>`;
      card.querySelector("button").addEventListener("click", () => {
        alert("This is a sample listing. Add the relevant PDF link in index.html before publishing.");
      });
      resourceGrid.appendChild(card);
    });
  });
  const empty = totalCards === 0;
  resourceGrid.hidden = empty;
  noResults.hidden = !empty;
}
search.addEventListener("input", renderResources);
libSemester.addEventListener("change", renderResources);
libType.addEventListener("change", renderResources);
document.getElementById("clearFilters").addEventListener("click", () => {
  search.value = ""; libSemester.value = "all"; libType.value = "all"; renderResources();
});
document.getElementById("menuBtn").addEventListener("click", () => {
  const side = document.getElementById("sidebar");
  side.classList.toggle("open");
  document.getElementById("menuBtn").setAttribute("aria-expanded", String(side.classList.contains("open")));
});
document.querySelectorAll(".side-link").forEach(link => link.addEventListener("click", () => {
  document.querySelectorAll(".side-link").forEach(item => item.classList.remove("selected"));
  link.classList.add("selected");
  document.getElementById("sidebar").classList.remove("open");
}));
document.addEventListener("keydown", event => {
  if (event.key === "/" && !["INPUT","TEXTAREA"].includes(document.activeElement.tagName)) {
    event.preventDefault(); search.focus();
  }
});
selectSemester("1");
renderResources();
